
# CloudZeroBeginner

Welcome to your automated, beginner-friendly Azure blog. Powered by GitHub Pages & Jekyll.

## Usage

- Add blog posts to the `_posts/` folder using Markdown.
- Posts must be named like `YYYY-MM-DD-title.md`.
- GitHub Pages will automatically build and host your site at https://vedasri12.github.io
